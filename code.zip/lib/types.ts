export interface Resident {
  id: string
  name: string
  age: number
  dateOfBirth: string
  gender: string
  contactNumber: string
  address: string
  emergencyContact: string
  bloodType: string
  allergies: string
  medications: string[]
  medicalConditions: string[]
  assignedTasks: Task[]
}

export interface Task {
  id: string
  title: string
  description: string
  assignedTo: string
  status: "pending" | "in-progress" | "completed"
  dueDate?: string
}

export const mockResidents: Resident[] = [
  {
    id: "RES001",
    name: "John Smith",
    age: 78,
    dateOfBirth: "1946-05-15",
    gender: "Male",
    contactNumber: "+1-555-0101",
    address: "123 Oak Street, Springfield, IL 62701",
    emergencyContact: "Sarah Smith (Daughter) +1-555-0102",
    bloodType: "O+",
    allergies: "Penicillin, Shellfish",
    medications: ["Lisinopril 10mg", "Metformin 500mg", "Aspirin 75mg"],
    medicalConditions: ["Hypertension", "Type 2 Diabetes", "Arthritis"],
    assignedTasks: [
      {
        id: "T001",
        title: "Morning Medication",
        description: "Administer blood pressure and diabetes medications",
        assignedTo: "Nurse Maria",
        status: "completed",
        dueDate: "2024-01-15",
      },
      {
        id: "T002",
        title: "Physical Therapy",
        description: "Assisted walking session - 30 minutes",
        assignedTo: "Therapist David",
        status: "in-progress",
        dueDate: "2024-01-15",
      },
      {
        id: "T003",
        title: "Meal Assistance",
        description: "Help with lunch preparation and feeding",
        assignedTo: "Care Assistant Lisa",
        status: "pending",
        dueDate: "2024-01-15",
      },
    ],
  },
  {
    id: "RES002",
    name: "Margaret Johnson",
    age: 82,
    dateOfBirth: "1942-08-22",
    gender: "Female",
    contactNumber: "+1-555-0103",
    address: "456 Elm Avenue, Springfield, IL 62702",
    emergencyContact: "Robert Johnson (Son) +1-555-0104",
    bloodType: "A-",
    allergies: "Sulfonamides",
    medications: ["Atorvastatin 20mg", "Levothyroxine 75mg", "Calcium 1000mg"],
    medicalConditions: ["High Cholesterol", "Hypothyroidism", "Osteoporosis"],
    assignedTasks: [
      {
        id: "T004",
        title: "Vital Signs Check",
        description: "Blood pressure, temperature, and heart rate",
        assignedTo: "Nurse John",
        status: "completed",
        dueDate: "2024-01-15",
      },
    ],
  },
  {
    id: "RES003",
    name: "William Brown",
    age: 75,
    dateOfBirth: "1949-03-10",
    gender: "Male",
    contactNumber: "+1-555-0105",
    address: "789 Pine Road, Springfield, IL 62703",
    emergencyContact: "Emma Brown (Daughter) +1-555-0106",
    bloodType: "B+",
    allergies: "None",
    medications: ["Warfarin 5mg", "Furosemide 40mg"],
    medicalConditions: ["Atrial Fibrillation", "Heart Failure"],
    assignedTasks: [],
  },
  {
    id: "RES004",
    name: "Dorothy Davis",
    age: 80,
    dateOfBirth: "1944-11-05",
    gender: "Female",
    contactNumber: "+1-555-0107",
    address: "321 Birch Lane, Springfield, IL 62704",
    emergencyContact: "James Davis (Son) +1-555-0108",
    bloodType: "AB+",
    allergies: "Codeine",
    medications: ["Metoprolol 50mg", "Amlodipine 5mg", "Sertraline 50mg"],
    medicalConditions: ["Hypertension", "Depression", "Anxiety"],
    assignedTasks: [
      {
        id: "T005",
        title: "Mental Health Check-in",
        description: "Counseling session with psychologist",
        assignedTo: "Counselor Patricia",
        status: "in-progress",
        dueDate: "2024-01-15",
      },
    ],
  },
]
