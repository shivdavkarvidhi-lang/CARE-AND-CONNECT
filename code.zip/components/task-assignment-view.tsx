"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { Resident, Task } from "@/lib/types"
import { Plus, CheckCircle2, Clock, AlertCircle } from "lucide-react"

interface TaskAssignmentViewProps {
  residents: Resident[]
  onCreateTask: () => void
  onEditTask: (task: Task, resident: Resident) => void
}

export default function TaskAssignmentView({ residents, onCreateTask, onEditTask }: TaskAssignmentViewProps) {
  // Collect all tasks from all residents
  const allTasks = residents.flatMap((resident) =>
    resident.assignedTasks.map((task) => ({
      task,
      resident,
    })),
  )

  // Group tasks by status
  const tasksByStatus = {
    pending: allTasks.filter(({ task }) => task.status === "pending"),
    "in-progress": allTasks.filter(({ task }) => task.status === "in-progress"),
    completed: allTasks.filter(({ task }) => task.status === "completed"),
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle2 className="w-4 h-4 text-accent" />
      case "in-progress":
        return <Clock className="w-4 h-4 text-primary" />
      default:
        return <AlertCircle className="w-4 h-4 text-muted-foreground" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-accent/10 text-accent"
      case "in-progress":
        return "bg-primary/10 text-primary"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-foreground">Task Assignment</h2>
        <Button onClick={onCreateTask} className="bg-primary">
          <Plus className="w-4 h-4 mr-2" />
          New Task
        </Button>
      </div>

      {/* Task Statistics */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="p-4 border">
          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground">Pending</p>
            <p className="text-3xl font-bold text-foreground">{tasksByStatus.pending.length}</p>
          </div>
        </Card>
        <Card className="p-4 border">
          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground">In Progress</p>
            <p className="text-3xl font-bold text-primary">{tasksByStatus["in-progress"].length}</p>
          </div>
        </Card>
        <Card className="p-4 border">
          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground">Completed</p>
            <p className="text-3xl font-bold text-accent">{tasksByStatus.completed.length}</p>
          </div>
        </Card>
      </div>

      {/* Tasks by Status */}
      <div className="space-y-6">
        {(["pending", "in-progress", "completed"] as const).map((status) => (
          <div key={status}>
            <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
              {getStatusIcon(status)}
              {status.charAt(0).toUpperCase() + status.slice(1).replace("-", " ")} ({tasksByStatus[status].length})
            </h3>

            {tasksByStatus[status].length > 0 ? (
              <div className="space-y-3">
                {tasksByStatus[status].map(({ task, resident }) => (
                  <Card key={task.id} className="p-4 border hover:border-primary/50 transition">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-start gap-3 mb-2">
                          <div className="flex-1">
                            <p className="font-semibold text-foreground">{task.title}</p>
                            <p className="text-sm text-muted-foreground mt-1">{task.description}</p>
                          </div>
                          <Badge variant="outline" className={getStatusColor(status)}>
                            {status.charAt(0).toUpperCase() + status.slice(1)}
                          </Badge>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3 text-xs">
                          <div>
                            <p className="font-medium text-muted-foreground">Resident</p>
                            <p className="text-foreground">{resident.name}</p>
                          </div>
                          <div>
                            <p className="font-medium text-muted-foreground">Assigned To</p>
                            <p className="text-foreground">{task.assignedTo}</p>
                          </div>
                          {task.dueDate && (
                            <div>
                              <p className="font-medium text-muted-foreground">Due Date</p>
                              <p className="text-foreground">{new Date(task.dueDate).toLocaleDateString()}</p>
                            </div>
                          )}
                          <div>
                            <p className="font-medium text-muted-foreground">Task ID</p>
                            <p className="text-foreground font-mono">{task.id}</p>
                          </div>
                        </div>
                      </div>

                      <Button variant="outline" size="sm" onClick={() => onEditTask(task, resident)}>
                        Edit
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="p-8 border text-center">
                <p className="text-muted-foreground">No {status} tasks</p>
              </Card>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
