"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Plus, Search } from "lucide-react"
import { type Resident, mockResidents } from "@/lib/types"

interface ResidentListProps {
  selectedResident: Resident | null
  onSelectResident: (resident: Resident) => void
}

export default function ResidentList({ selectedResident, onSelectResident }: ResidentListProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [residents, setResidents] = useState<Resident[]>(mockResidents)

  const filteredResidents = residents.filter(
    (resident) =>
      resident.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resident.id.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <Card className="h-full flex flex-col border">
      <div className="p-4 border-b border-border">
        <div className="flex gap-2 mb-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search residents..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        <Button className="w-full bg-primary hover:bg-primary/90" size="sm">
          <Plus className="w-4 h-4 mr-2" />
          Add Resident
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {filteredResidents.length === 0 ? (
          <div className="p-4 text-center text-muted-foreground text-sm">No residents found</div>
        ) : (
          filteredResidents.map((resident) => (
            <button
              key={resident.id}
              onClick={() => onSelectResident(resident)}
              className={`w-full text-left p-4 border-b border-border transition ${
                selectedResident?.id === resident.id ? "bg-primary/10 border-l-4 border-l-primary" : "hover:bg-muted"
              }`}
            >
              <div className="font-medium text-foreground">{resident.name}</div>
              <div className="text-xs text-muted-foreground mt-1">{resident.id}</div>
              <div className="text-xs text-muted-foreground mt-1">Age: {resident.age}</div>
            </button>
          ))
        )}
      </div>
    </Card>
  )
}
