"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Resident } from "@/lib/types"
import { X, Plus } from "lucide-react"

interface MedicalHistoryEditProps {
  resident: Resident
  open: boolean
  onOpenChange: (open: boolean) => void
  onSave: (updatedResident: Resident) => void
}

export default function MedicalHistoryEdit({ resident, open, onOpenChange, onSave }: MedicalHistoryEditProps) {
  const [formData, setFormData] = useState<Resident>(resident)
  const [newMedication, setNewMedication] = useState("")
  const [newCondition, setNewCondition] = useState("")

  const handleChange = (field: keyof Resident, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleAddMedication = () => {
    if (newMedication.trim()) {
      setFormData((prev) => ({
        ...prev,
        medications: [...prev.medications, newMedication.trim()],
      }))
      setNewMedication("")
    }
  }

  const handleRemoveMedication = (idx: number) => {
    setFormData((prev) => ({
      ...prev,
      medications: prev.medications.filter((_, i) => i !== idx),
    }))
  }

  const handleAddCondition = () => {
    if (newCondition.trim()) {
      setFormData((prev) => ({
        ...prev,
        medicalConditions: [...prev.medicalConditions, newCondition.trim()],
      }))
      setNewCondition("")
    }
  }

  const handleRemoveCondition = (idx: number) => {
    setFormData((prev) => ({
      ...prev,
      medicalConditions: prev.medicalConditions.filter((_, i) => i !== idx),
    }))
  }

  const handleSave = () => {
    onSave(formData)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Medical History</DialogTitle>
          <DialogDescription>Update medical records, medications, and conditions</DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Blood Type */}
          <div className="space-y-2">
            <Label htmlFor="blood-type">Blood Type</Label>
            <Select value={formData.bloodType} onValueChange={(value) => handleChange("bloodType", value)}>
              <SelectTrigger id="blood-type">
                <SelectValue placeholder="Select blood type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="O+">O+</SelectItem>
                <SelectItem value="O-">O-</SelectItem>
                <SelectItem value="A+">A+</SelectItem>
                <SelectItem value="A-">A-</SelectItem>
                <SelectItem value="B+">B+</SelectItem>
                <SelectItem value="B-">B-</SelectItem>
                <SelectItem value="AB+">AB+</SelectItem>
                <SelectItem value="AB-">AB-</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Allergies */}
          <div className="space-y-2">
            <Label htmlFor="allergies">Known Allergies (comma-separated)</Label>
            <Textarea
              id="allergies"
              value={formData.allergies}
              onChange={(e) => handleChange("allergies", e.target.value)}
              placeholder="e.g., Penicillin, Shellfish, Latex"
              rows={2}
            />
            <p className="text-xs text-muted-foreground">Separate multiple allergies with commas</p>
          </div>

          {/* Current Medications */}
          <div className="space-y-3">
            <Label>Current Medications</Label>
            <div className="flex gap-2">
              <Input
                value={newMedication}
                onChange={(e) => setNewMedication(e.target.value)}
                placeholder="e.g., Lisinopril 10mg"
                onKeyPress={(e) => {
                  if (e.key === "Enter") {
                    handleAddMedication()
                  }
                }}
              />
              <Button type="button" variant="outline" onClick={handleAddMedication} size="sm">
                <Plus className="w-4 h-4" />
              </Button>
            </div>

            {formData.medications.length > 0 && (
              <div className="space-y-2">
                {formData.medications.map((med, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-3 bg-muted rounded-lg border border-border"
                  >
                    <span className="text-sm text-foreground">{med}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveMedication(idx)}
                      className="text-destructive hover:bg-destructive/10 p-1 rounded transition"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Medical Conditions */}
          <div className="space-y-3">
            <Label>Medical Conditions</Label>
            <div className="flex gap-2">
              <Input
                value={newCondition}
                onChange={(e) => setNewCondition(e.target.value)}
                placeholder="e.g., Hypertension"
                onKeyPress={(e) => {
                  if (e.key === "Enter") {
                    handleAddCondition()
                  }
                }}
              />
              <Button type="button" variant="outline" onClick={handleAddCondition} size="sm">
                <Plus className="w-4 h-4" />
              </Button>
            </div>

            {formData.medicalConditions.length > 0 && (
              <div className="space-y-2">
                {formData.medicalConditions.map((condition, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-3 bg-amber-50 dark:bg-amber-950/30 rounded-lg border border-amber-200 dark:border-amber-800"
                  >
                    <span className="text-sm text-foreground">{condition}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveCondition(idx)}
                      className="text-destructive hover:bg-destructive/10 p-1 rounded transition"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} className="bg-primary">
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
