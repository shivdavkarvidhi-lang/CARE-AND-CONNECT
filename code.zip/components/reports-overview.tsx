"use client"

import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import type { Resident } from "@/lib/types"
import { Users, AlertCircle, CheckCircle2, Clock } from "lucide-react"

interface ReportsOverviewProps {
  residents: Resident[]
}

export default function ReportsOverview({ residents }: ReportsOverviewProps) {
  // Calculate statistics
  const totalResidents = residents.length
  const avgAge = Math.round(residents.reduce((sum, r) => sum + r.age, 0) / residents.length)

  // Collect all tasks
  const allTasks = residents.flatMap((r) => r.assignedTasks)
  const completedTasks = allTasks.filter((t) => t.status === "completed").length
  const inProgressTasks = allTasks.filter((t) => t.status === "in-progress").length
  const pendingTasks = allTasks.filter((t) => t.status === "pending").length
  const completionRate = Math.round((completedTasks / allTasks.length) * 100) || 0

  // Age distribution data
  const ageGroups = {
    "60-69": residents.filter((r) => r.age >= 60 && r.age < 70).length,
    "70-79": residents.filter((r) => r.age >= 70 && r.age < 80).length,
    "80-89": residents.filter((r) => r.age >= 80 && r.age < 90).length,
    "90+": residents.filter((r) => r.age >= 90).length,
  }

  const ageDistribution = Object.entries(ageGroups).map(([group, count]) => ({
    name: group,
    value: count,
  }))

  // Task status data
  const taskStatusData = [
    { name: "Completed", value: completedTasks },
    { name: "In Progress", value: inProgressTasks },
    { name: "Pending", value: pendingTasks },
  ]

  // Conditions frequency
  const conditionFrequency = residents.reduce(
    (acc, resident) => {
      resident.medicalConditions.forEach((condition) => {
        acc[condition] = (acc[condition] || 0) + 1
      })
      return acc
    },
    {} as Record<string, number>,
  )

  const topConditions = Object.entries(conditionFrequency)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 6)
    .map(([name, value]) => ({ name, value }))

  const COLORS = ["#06b6d4", "#0ea5e9", "#3b82f6", "#6366f1", "#8b5cf6", "#a78bfa"]

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Reports & Analytics</h2>
        <p className="text-muted-foreground">Comprehensive care facility monitoring and performance metrics</p>
      </div>

      {/* Key Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-6 border">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              <p className="text-sm font-medium text-muted-foreground">Total Residents</p>
            </div>
            <p className="text-3xl font-bold text-foreground">{totalResidents}</p>
            <p className="text-xs text-muted-foreground">Average age: {avgAge} years</p>
          </div>
        </Card>

        <Card className="p-6 border">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-accent" />
              <p className="text-sm font-medium text-muted-foreground">Completed Tasks</p>
            </div>
            <p className="text-3xl font-bold text-accent">{completedTasks}</p>
            <p className="text-xs text-muted-foreground">{completionRate}% completion rate</p>
          </div>
        </Card>

        <Card className="p-6 border">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-primary" />
              <p className="text-sm font-medium text-muted-foreground">In Progress</p>
            </div>
            <p className="text-3xl font-bold text-primary">{inProgressTasks}</p>
            <p className="text-xs text-muted-foreground">{allTasks.length} total tasks</p>
          </div>
        </Card>

        <Card className="p-6 border">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-destructive" />
              <p className="text-sm font-medium text-muted-foreground">Pending Tasks</p>
            </div>
            <p className="text-3xl font-bold text-destructive">{pendingTasks}</p>
            <p className="text-xs text-muted-foreground">Requires attention</p>
          </div>
        </Card>
      </div>

      {/* Charts */}
      <Tabs defaultValue="taskStatus" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-muted">
          <TabsTrigger value="taskStatus">Task Status</TabsTrigger>
          <TabsTrigger value="ageDistribution">Age Distribution</TabsTrigger>
          <TabsTrigger value="conditions">Medical Conditions</TabsTrigger>
        </TabsList>

        {/* Task Status Chart */}
        <TabsContent value="taskStatus" className="space-y-4">
          <Card className="p-6 border">
            <h3 className="text-lg font-semibold text-foreground mb-4">Task Status Distribution</h3>
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={taskStatusData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value}`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    <Cell fill="#06b6d4" />
                    <Cell fill="#0ea5e9" />
                    <Cell fill="#ef4444" />
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </TabsContent>

        {/* Age Distribution Chart */}
        <TabsContent value="ageDistribution" className="space-y-4">
          <Card className="p-6 border">
            <h3 className="text-lg font-semibold text-foreground mb-4">Resident Age Distribution</h3>
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={ageDistribution}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value" fill="#0ea5e9" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </TabsContent>

        {/* Medical Conditions Chart */}
        <TabsContent value="conditions" className="space-y-4">
          <Card className="p-6 border">
            <h3 className="text-lg font-semibold text-foreground mb-4">Top Medical Conditions</h3>
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topConditions} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis dataKey="name" type="category" width={150} />
                  <Tooltip />
                  <Bar dataKey="value" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Resident Details Table */}
      <Card className="p-6 border">
        <h3 className="text-lg font-semibold text-foreground mb-4">Resident Summary</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Resident Name</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Age</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Blood Type</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Allergies</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Tasks</th>
                <th className="text-left py-3 px-4 font-medium text-muted-foreground">Conditions</th>
              </tr>
            </thead>
            <tbody>
              {residents.map((resident) => (
                <tr key={resident.id} className="border-b border-border hover:bg-muted/50 transition">
                  <td className="py-3 px-4 font-medium text-foreground">{resident.name}</td>
                  <td className="py-3 px-4 text-foreground">{resident.age}</td>
                  <td className="py-3 px-4 text-foreground font-mono">{resident.bloodType}</td>
                  <td className="py-3 px-4 text-foreground text-xs">{resident.allergies}</td>
                  <td className="py-3 px-4">
                    <span className="inline-block bg-primary/10 text-primary px-2 py-1 rounded text-xs font-medium">
                      {resident.assignedTasks.length}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-foreground">{resident.medicalConditions.length}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
