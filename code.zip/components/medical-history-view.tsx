"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { Resident } from "@/lib/types"
import { Edit2, AlertCircle, Pill } from "lucide-react"

interface MedicalHistoryViewProps {
  resident: Resident
  onEdit: () => void
}

export default function MedicalHistoryView({ resident, onEdit }: MedicalHistoryViewProps) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground">Medical History & Records</h3>
        <Button variant="outline" size="sm" onClick={onEdit}>
          <Edit2 className="w-4 h-4 mr-2" />
          Edit
        </Button>
      </div>

      {/* Blood Type & Allergies Alert */}
      <Card className="p-6 border bg-accent/5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-accent" />
              <p className="text-sm font-semibold text-foreground">Blood Type</p>
            </div>
            <p className="text-2xl font-bold text-accent">{resident.bloodType}</p>
          </div>

          <div className="space-y-2">
            <p className="text-sm font-semibold text-foreground">Critical Allergies</p>
            {resident.allergies && resident.allergies !== "None" ? (
              <div className="flex flex-wrap gap-2">
                {resident.allergies.split(",").map((allergy, idx) => (
                  <Badge key={idx} variant="destructive" className="text-xs">
                    {allergy.trim()}
                  </Badge>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No known allergies</p>
            )}
          </div>
        </div>
      </Card>

      {/* Current Medications */}
      <Card className="p-6 border">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Pill className="w-5 h-5 text-primary" />
            <h4 className="font-semibold text-foreground">Current Medications</h4>
          </div>

          {resident.medications.length > 0 ? (
            <div className="space-y-3">
              {resident.medications.map((med, idx) => (
                <div key={idx} className="p-4 bg-muted rounded-lg border border-border">
                  <p className="text-sm font-medium text-foreground">{med}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground p-4 text-center bg-muted rounded-lg">
              No medications currently recorded
            </p>
          )}
        </div>
      </Card>

      {/* Medical Conditions */}
      <Card className="p-6 border">
        <div className="space-y-4">
          <h4 className="font-semibold text-foreground">Active Medical Conditions</h4>

          {resident.medicalConditions.length > 0 ? (
            <div className="space-y-3">
              {resident.medicalConditions.map((condition, idx) => (
                <div
                  key={idx}
                  className="p-4 bg-amber-50 dark:bg-amber-950/30 rounded-lg border border-amber-200 dark:border-amber-800"
                >
                  <p className="text-sm font-medium text-foreground">{condition}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground p-4 text-center bg-muted rounded-lg">
              No medical conditions recorded
            </p>
          )}
        </div>
      </Card>
    </div>
  )
}
