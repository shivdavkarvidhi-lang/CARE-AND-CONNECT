"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { Resident } from "@/lib/types"
import { User, Heart, ClipboardList, Edit2 } from "lucide-react"
import PersonalInfoView from "./personal-info-view"
import PersonalInfoEdit from "./personal-info-edit"
import MedicalHistoryView from "./medical-history-view"
import MedicalHistoryEdit from "./medical-history-edit"

interface ResidentDetailProps {
  resident: Resident
}

export default function ResidentDetail({ resident: initialResident }: ResidentDetailProps) {
  const [activeTab, setActiveTab] = useState("personal")
  const [resident, setResident] = useState(initialResident)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [medicalEditDialogOpen, setMedicalEditDialogOpen] = useState(false)

  const handleSavePersonalInfo = (updatedResident: Resident) => {
    setResident(updatedResident)
  }

  const handleSaveMedicalInfo = (updatedResident: Resident) => {
    setResident(updatedResident)
  }

  return (
    <div className="space-y-6">
      {/* Header Card */}
      <Card className="p-6 border">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 bg-primary/20 rounded-lg flex items-center justify-center">
              <User className="w-8 h-8 text-primary" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-foreground">{resident.name}</h2>
              <p className="text-sm text-muted-foreground">ID: {resident.id}</p>
              <p className="text-sm text-muted-foreground">Age: {resident.age} years</p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={() => setEditDialogOpen(true)}>
            <Edit2 className="w-4 h-4 mr-2" />
            Edit
          </Button>
        </div>
      </Card>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-muted">
          <TabsTrigger value="personal" className="flex items-center gap-2">
            <User className="w-4 h-4" />
            <span className="hidden sm:inline">Personal Info</span>
          </TabsTrigger>
          <TabsTrigger value="medical" className="flex items-center gap-2">
            <Heart className="w-4 h-4" />
            <span className="hidden sm:inline">Medical History</span>
          </TabsTrigger>
          <TabsTrigger value="tasks" className="flex items-center gap-2">
            <ClipboardList className="w-4 h-4" />
            <span className="hidden sm:inline">Assigned Tasks</span>
          </TabsTrigger>
        </TabsList>

        {/* Personal Information Tab */}
        <TabsContent value="personal" className="space-y-4">
          <PersonalInfoView resident={resident} onEdit={() => setEditDialogOpen(true)} />
        </TabsContent>

        {/* Medical History Tab */}
        <TabsContent value="medical" className="space-y-4">
          <MedicalHistoryView resident={resident} onEdit={() => setMedicalEditDialogOpen(true)} />
        </TabsContent>

        {/* Assigned Tasks Tab */}
        <TabsContent value="tasks" className="space-y-4">
          <Card className="p-6 border">
            <h3 className="text-lg font-semibold text-foreground mb-4">Assigned Tasks</h3>
            <div className="space-y-3">
              {resident.assignedTasks.map((task, idx) => (
                <div key={idx} className="p-4 border border-border rounded-lg flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{task.title}</p>
                    <p className="text-sm text-muted-foreground mt-1">{task.description}</p>
                    <p className="text-xs text-muted-foreground mt-2">Assigned to: {task.assignedTo}</p>
                  </div>
                  <div
                    className={`px-3 py-1 rounded text-xs font-medium ${
                      task.status === "completed"
                        ? "bg-accent/20 text-accent"
                        : task.status === "in-progress"
                          ? "bg-primary/20 text-primary"
                          : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {task.status.charAt(0).toUpperCase() + task.status.slice(1)}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      <PersonalInfoEdit
        resident={resident}
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
        onSave={handleSavePersonalInfo}
      />

      <MedicalHistoryEdit
        resident={resident}
        open={medicalEditDialogOpen}
        onOpenChange={setMedicalEditDialogOpen}
        onSave={handleSaveMedicalInfo}
      />
    </div>
  )
}
