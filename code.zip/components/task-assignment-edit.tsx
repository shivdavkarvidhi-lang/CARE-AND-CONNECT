"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Resident, Task } from "@/lib/types"

interface TaskAssignmentEditProps {
  residents: Resident[]
  task: Task | null
  selectedResident: Resident | null
  open: boolean
  onOpenChange: (open: boolean) => void
  onSave: (task: Task, residentId: string) => void
}

export default function TaskAssignmentEdit({
  residents,
  task,
  selectedResident,
  open,
  onOpenChange,
  onSave,
}: TaskAssignmentEditProps) {
  const [formData, setFormData] = useState<Task>(
    task || {
      id: `T${Date.now()}`,
      title: "",
      description: "",
      assignedTo: "",
      status: "pending",
      dueDate: "",
    },
  )
  const [selectedResidentId, setSelectedResidentId] = useState(selectedResident?.id || "")

  const handleChange = (field: keyof Task, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleSave = () => {
    if (formData.title && formData.description && formData.assignedTo && selectedResidentId) {
      onSave(formData, selectedResidentId)
      onOpenChange(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{task ? "Edit Task" : "Create New Task"}</DialogTitle>
          <DialogDescription>
            {task ? "Update task details and assignment" : "Create and assign a new task to a resident"}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Resident Selection */}
          <div className="space-y-2">
            <Label htmlFor="resident">Select Resident</Label>
            <Select value={selectedResidentId} onValueChange={setSelectedResidentId}>
              <SelectTrigger id="resident">
                <SelectValue placeholder="Choose a resident" />
              </SelectTrigger>
              <SelectContent>
                {residents.map((resident) => (
                  <SelectItem key={resident.id} value={resident.id}>
                    {resident.name} (ID: {resident.id})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Task Title */}
          <div className="space-y-2">
            <Label htmlFor="title">Task Title</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => handleChange("title", e.target.value)}
              placeholder="e.g., Morning Medication"
            />
          </div>

          {/* Task Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Task Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleChange("description", e.target.value)}
              placeholder="Detailed description of the task"
              rows={3}
            />
          </div>

          {/* Assigned To */}
          <div className="space-y-2">
            <Label htmlFor="assignedTo">Assigned To (Staff Name)</Label>
            <Input
              id="assignedTo"
              value={formData.assignedTo}
              onChange={(e) => handleChange("assignedTo", e.target.value)}
              placeholder="e.g., Nurse Maria"
            />
          </div>

          {/* Due Date */}
          <div className="space-y-2">
            <Label htmlFor="dueDate">Due Date</Label>
            <Input
              id="dueDate"
              type="date"
              value={formData.dueDate || ""}
              onChange={(e) => handleChange("dueDate", e.target.value)}
            />
          </div>

          {/* Status */}
          <div className="space-y-2">
            <Label htmlFor="status">Task Status</Label>
            <Select value={formData.status} onValueChange={(value) => handleChange("status", value as any)}>
              <SelectTrigger id="status">
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="in-progress">In Progress</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} className="bg-primary">
            {task ? "Update Task" : "Create Task"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
