"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { LogOut, Menu, X } from "lucide-react"
import ResidentList from "./resident-list"
import ResidentDetail from "./resident-detail"
import TaskAssignmentView from "./task-assignment-view"
import TaskAssignmentEdit from "./task-assignment-edit"
import ReportsOverview from "./reports-overview"
import type { Resident, Task } from "@/lib/types"
import { mockResidents } from "@/lib/types"

interface DashboardProps {
  staffName: string
  onLogout: () => void
}

export default function Dashboard({ staffName, onLogout }: DashboardProps) {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [selectedResident, setSelectedResident] = useState<Resident | null>(null)
  const [activeTab, setActiveTab] = useState<"residents" | "tasks" | "reports">("residents")
  const [residents, setResidents] = useState(mockResidents)
  const [taskEditOpen, setTaskEditOpen] = useState(false)
  const [selectedTask, setSelectedTask] = useState<Task | null>(null)

  const handleCreateTask = () => {
    setSelectedTask(null)
    setTaskEditOpen(true)
  }

  const handleEditTask = (task: Task, resident: Resident) => {
    setSelectedTask(task)
    setSelectedResident(resident)
    setTaskEditOpen(true)
  }

  const handleSaveTask = (task: Task, residentId: string) => {
    setResidents((prev) =>
      prev.map((resident) => {
        if (resident.id === residentId) {
          const existingTaskIndex = resident.assignedTasks.findIndex((t) => t.id === task.id)
          if (existingTaskIndex >= 0) {
            const updatedTasks = [...resident.assignedTasks]
            updatedTasks[existingTaskIndex] = task
            return { ...resident, assignedTasks: updatedTasks }
          } else {
            return { ...resident, assignedTasks: [...resident.assignedTasks, task] }
          }
        }
        return resident
      }),
    )
    setTaskEditOpen(false)
    setSelectedTask(null)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-40">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-4">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 hover:bg-muted rounded-lg transition">
              {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <h1 className="text-xl font-bold text-foreground">CareHub</h1>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm font-medium text-foreground">Welcome, {staffName}</p>
              <p className="text-xs text-muted-foreground">Care Staff</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onLogout}
              className="text-muted-foreground hover:text-foreground"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        {sidebarOpen && (
          <aside className="w-64 bg-sidebar border-r border-sidebar-border p-6 min-h-[calc(100vh-80px)]">
            <nav className="space-y-2">
              <button
                onClick={() => {
                  setActiveTab("residents")
                  setSelectedResident(null)
                }}
                className={`w-full text-left px-4 py-3 rounded-lg transition ${
                  activeTab === "residents"
                    ? "bg-sidebar-primary text-sidebar-primary-foreground"
                    : "text-sidebar-foreground hover:bg-sidebar-accent"
                }`}
              >
                Residents
              </button>
              <button
                onClick={() => setActiveTab("tasks")}
                className={`w-full text-left px-4 py-3 rounded-lg transition ${
                  activeTab === "tasks"
                    ? "bg-sidebar-primary text-sidebar-primary-foreground"
                    : "text-sidebar-foreground hover:bg-sidebar-accent"
                }`}
              >
                Task Assignment
              </button>
              <button
                onClick={() => setActiveTab("reports")}
                className={`w-full text-left px-4 py-3 rounded-lg transition ${
                  activeTab === "reports"
                    ? "bg-sidebar-primary text-sidebar-primary-foreground"
                    : "text-sidebar-foreground hover:bg-sidebar-accent"
                }`}
              >
                Reports
              </button>
            </nav>
          </aside>
        )}

        {/* Main Content */}
        <main className="flex-1 p-6">
          {activeTab === "residents" && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-1">
                <ResidentList selectedResident={selectedResident} onSelectResident={setSelectedResident} />
              </div>
              <div className="lg:col-span-2">
                {selectedResident ? (
                  <ResidentDetail resident={selectedResident} />
                ) : (
                  <div className="bg-card rounded-lg p-12 text-center border border-border">
                    <p className="text-muted-foreground">Select a resident to view details</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === "tasks" && (
            <TaskAssignmentView residents={residents} onCreateTask={handleCreateTask} onEditTask={handleEditTask} />
          )}

          {activeTab === "reports" && <ReportsOverview residents={residents} />}
        </main>
      </div>

      <TaskAssignmentEdit
        residents={residents}
        task={selectedTask}
        selectedResident={selectedResident}
        open={taskEditOpen}
        onOpenChange={setTaskEditOpen}
        onSave={handleSaveTask}
      />
    </div>
  )
}
