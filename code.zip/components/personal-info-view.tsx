"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { Resident } from "@/lib/types"
import { Edit2 } from "lucide-react"

interface PersonalInfoViewProps {
  resident: Resident
  onEdit: () => void
}

export default function PersonalInfoView({ resident, onEdit }: PersonalInfoViewProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground">Personal Information</h3>
        <Button variant="outline" size="sm" onClick={onEdit}>
          <Edit2 className="w-4 h-4 mr-2" />
          Edit
        </Button>
      </div>

      <Card className="p-6 border">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground">Full Name</p>
            <p className="text-sm font-medium text-foreground">{resident.name}</p>
          </div>

          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground">Age</p>
            <p className="text-sm text-foreground">{resident.age} years</p>
          </div>

          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground">Gender</p>
            <p className="text-sm text-foreground">{resident.gender}</p>
          </div>

          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground">Date of Birth</p>
            <p className="text-sm text-foreground">{resident.dateOfBirth}</p>
          </div>

          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground">Contact Number</p>
            <p className="text-sm text-foreground">{resident.contactNumber}</p>
          </div>

          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground">Resident ID</p>
            <p className="text-sm text-foreground font-mono">{resident.id}</p>
          </div>

          <div className="space-y-2 col-span-2 md:col-span-3">
            <p className="text-xs font-medium text-muted-foreground">Address</p>
            <p className="text-sm text-foreground">{resident.address}</p>
          </div>

          <div className="space-y-2 col-span-2 md:col-span-3">
            <p className="text-xs font-medium text-muted-foreground">Emergency Contact</p>
            <p className="text-sm text-foreground">{resident.emergencyContact}</p>
          </div>
        </div>
      </Card>
    </div>
  )
}
